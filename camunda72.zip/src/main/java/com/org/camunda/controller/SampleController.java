package com.org.camunda.controller;

import com.org.camunda.model.NativeJsonDemoRequestDto;
import com.org.camunda.model.Person;
import com.org.camunda.model.Summers;
import com.org.camunda.service.CamundaStartService;
import com.org.camunda.service.FormatCamundaRequestsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class SampleController {

    @Autowired
    CamundaStartService camundaStartService;

    @Autowired
    FormatCamundaRequestsService camundaRequestsService;

    @GetMapping("/get")
    public String index() {
        return "Greetings from Spring Boot!";
    }

    @PostMapping("/msgeventstart")
    public void persistPerson(@RequestBody Person obj) throws Exception {
        camundaStartService.startProcessByMessage2(obj);
    }

//    @PostMapping("/msgs2")
//    public void msgs2(@RequestBody String name) {
//        camundaStartService.startProcessByMessage2(name);
//    }

    @GetMapping("/getconnector/{name}")
    public int getConnector(@PathVariable String name) {
        return name.length();
    }

    @RequestMapping(value = "/postconnector", method = RequestMethod.POST)
    public int msgs2(@RequestBody Summers summers) {
        return summers.getNum1() + summers.getNum2() + summers.getNum3() + summers.getNum4();
    }

    @PostMapping(path = "/demonativejson")
    public void demoNativeJson(@RequestBody NativeJsonDemoRequestDto nativeJsonDemoRequestDto){
        camundaRequestsService.callNativeJsonDemoSample(nativeJsonDemoRequestDto);
    }
}
