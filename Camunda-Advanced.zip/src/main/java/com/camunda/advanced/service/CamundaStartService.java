package com.camunda.advanced.service;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.camunda.bpm.engine.variable.value.SerializableValue;
import org.camunda.spin.plugin.variable.SpinValues;
import org.camunda.spin.plugin.variable.value.JsonValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.camunda.advanced.model.CommonAttribute;
import com.camunda.advanced.model.Person;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CamundaStartService {
    @Autowired
    RuntimeService runtimeService;



    public void startProcessByMessage2(Person person) throws Exception {
        String name = person.getName();
        String gender = person.getGender();

        ObjectMapper obj = new ObjectMapper();//this object mapper will catch Person pojo and convert that into string
        String json = obj.writeValueAsString(person);

        ObjectValue typedPersonValue = Variables.objectValue(person).serializationDataFormat("application/json").create(); //application json lets you all class function...
        runtimeService.createMessageCorrelation("msg")
                .setVariable("name", name)
                .setVariable("customSerialized", typedPersonValue)//it is not a json, it is literal object
                .setVariable("customJson", json)
                .correlate();


    }
    

    
    
    public void startProcessByMessage3(CommonAttribute common) throws Exception {
    	String category = common.getCategory();
    	String subCategory = common.getSubCategory();
    	String departmentName = common.getDepartmentName();
    	String planType = common.getPlanType();
    	int memberId = common.getMemberId();
    	
    	 int groupTypeCode = common.getGroupTypeCode();
    	 String productBrandGrouping = common.getProductBrandGrouping();

        ObjectMapper obj = new ObjectMapper();//this object mapper will catch Person pojo and convert that into string
//        obj.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String json = obj.writeValueAsString(common);
        
        


        ObjectValue commonObj = Variables.objectValue(common).serializationDataFormat("application/json").create();
//     JsonValue jsonValue = (JsonValue) SpinValues.jsonValue(common.toString()).create();
     
//     JsonValue jsonValue = SpinValues.jsonValue(json).create();
        //application json lets you all class function...
         
        runtimeService.createMessageCorrelation("rule-msg")
                .setVariable("category", category)
                .setVariable("subCategory", subCategory)
                .setVariable("departmentName", departmentName)
                .setVariable("memberId", memberId)
                .setVariable("groupTypeCode", groupTypeCode)
                .setVariable("productBrandGrouping", productBrandGrouping)
                .setVariable("planType", planType)
                .setVariable("customSerialized", commonObj)
                .setVariable("customJson", json)
                .correlate();
//        
//        ObjectValue common1 = runtimeService.getVariableTyped(json, "common");
//        String customerJson = ((SerializableValue) common).getValueSerialized();
        
        
//        ObjectValue customer = runtimeService.getVariableTyped(processInstance.getId(), "customer");
//        String customerJson = customer.getValueSerialized();
        
              
        //processInstance.getId(), "customer", new CommonAttribute()
        
        
        
    
     
        
        

    }

}
