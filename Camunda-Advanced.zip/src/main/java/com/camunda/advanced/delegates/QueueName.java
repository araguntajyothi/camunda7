package com.camunda.advanced.delegates;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.camunda.advanced.model.CommonAttribute;

public class QueueName implements JavaDelegate {
Logger logger = LoggerFactory.getLogger(QueueName.class);



	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		
			
		

		logger.info("*********** Output **********");
		logger.info("Queue Name : "+execution.getVariable("QueueName"));
	}

}

