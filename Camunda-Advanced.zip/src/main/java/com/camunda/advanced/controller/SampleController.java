package com.camunda.advanced.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.camunda.advanced.model.CommonAttribute;
import com.camunda.advanced.model.NativeJsonDemoRequestDto;
import com.camunda.advanced.model.Person;
import com.camunda.advanced.model.Summers;
import com.camunda.advanced.service.CamundaStartService;
import com.camunda.advanced.service.FormatCamundaRequestsService;

@RestController
public class SampleController {

	//Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    CamundaStartService camundaStartService;

    @Autowired
    FormatCamundaRequestsService camundaRequestsService;
    
    @Autowired
    private CommonAttribute commonAttr;


    @PostMapping("/msgstart")
    public void persistPerson(@RequestBody Person obj) throws Exception {
        camundaStartService.startProcessByMessage2(obj);
    }
    
    @PostMapping("/msgruleStart")
    public void persistRules(@RequestBody CommonAttribute commonAttr) throws Exception {
        camundaStartService.startProcessByMessage3(commonAttr);
    }
 
   // http://localhost:8089/getConnector/${planType}

    @GetMapping(path="getData")
    public Map<String, Object> getData() {
      Map<String, Object> map = new HashMap();
    	
    	map.put("productBrandGrouping", "Commercial");
    	map.put("groupTypeCode", 106);
    	System.out.println(map);
    	
    	
		return map;
    }
    
    @GetMapping("/getconnector/{name}")
    public int getConnector(@PathVariable String name) {
        return name.length();
    }
    

    @RequestMapping(value = "/postconnector", method = RequestMethod.POST)
    public int msgs2(@RequestBody Summers summers) {
        return summers.getNum1() + summers.getNum2() + summers.getNum3() + summers.getNum4();
    }

    @PostMapping(path = "/demonativejson")
    public void demoNativeJson(@RequestBody NativeJsonDemoRequestDto nativeJsonDemoRequestDto){
    	camundaRequestsService.callNativeJsonDemoSample(nativeJsonDemoRequestDto);
    }
}
