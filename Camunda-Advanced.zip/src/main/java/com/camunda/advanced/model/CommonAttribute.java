package com.camunda.advanced.model;

import org.springframework.stereotype.Component;

@Component
public class CommonAttribute {
	
	private String category;
	private String subCategory;
	private String departmentName;
	private String QueueName;
	private String planType;
	private int memberId;
	private int groupTypeCode;
	private String productBrandGrouping;
	
	public CommonAttribute() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommonAttribute(String category, String subCategory, String departmentName, String queueName,
			String planType, int memberId, int groupTypeCode, String productBrandGrouping) {
		super();
		this.category = category;
		this.subCategory = subCategory;
		this.departmentName = departmentName;
		QueueName = queueName;
		this.planType = planType;
		this.memberId = memberId;
		this.groupTypeCode = groupTypeCode;
		this.productBrandGrouping = productBrandGrouping;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getQueueName() {
		return QueueName;
	}

	public void setQueueName(String queueName) {
		QueueName = queueName;
	}

	public String getPlanType() {
		return planType;
	}

	public void setPlanType(String planType) {
		this.planType = planType;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public int getGroupTypeCode() {
		return groupTypeCode;
	}

	public void setGroupTypeCode(int groupTypeCode) {
		this.groupTypeCode = groupTypeCode;
	}

	public String getProductBrandGrouping() {
		return productBrandGrouping;
	}

	public void setProductBrandGrouping(String productBrandGrouping) {
		this.productBrandGrouping = productBrandGrouping;
	}



//	@Override
//	public String toString() {
//		return "CommonAttribute [category=" + category + ", subCategory=" + subCategory + ", departmentName="
//				+ departmentName + ", QueueName=" + QueueName + ", planType=" + planType + ", memberId=" + memberId
//				+ ", groupTypeCode=" + groupTypeCode + ", productBrandGrouping=" + productBrandGrouping + "]";
//	}
	
	
	
	
	


	
	
	
	
	
	

}
