package com.org.camunda.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.org.camunda.pojo.Person;
import com.org.camunda.pojo.Summers;
import com.org.camunda.service.CamundaStartService;

@RestController
public class SampleController {
	@Autowired
	CamundaStartService camundaStartService;

	
	@PostMapping(value="/msgeventstart")
	public void persistPerson(@RequestBody Person obj) {
		camundaStartService.startProcessByMessage(obj);
	}
	
	@PostMapping(value="/msgs2")
	public void msgs2(@RequestBody String name) {
		camundaStartService.startProcessByMessage2(name);
	}
	
	@GetMapping(value="/getconnector/{name}")
	public int getConnector(@PathVariable String name) {
		return name.length();
		
	}
	
	@PostMapping(value="/postconnector")
	public int msgs2(@RequestBody Summers summers) {
		return summers.getNum1() + summers.getNum2() + summers.getNum3() + summers.getNum4();
	}
	

}
