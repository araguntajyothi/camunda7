package com.org.camunda.listener;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.engine.delegate.Expression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MessageServiceExecutionListener implements ExecutionListener {
	Logger LOGGER = LoggerFactory.getLogger(MessageServiceExecutionListener.class);
	Expression inj1;
	Expression inj2;
	String injval;
	String wish;
	
	@Override
	public void notify(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		injval = (String) inj1.getValue(execution);
		wish = (String) inj2.getValue(execution);
		LOGGER.info("Executed execution listener inj1 with value: "+injval);
		LOGGER.info("Executed execution listener inj1 with value: "+wish);
//		Hello ${gender=='male' ? 'Mr' :'Mrs'} ${name}
		
	}

}
