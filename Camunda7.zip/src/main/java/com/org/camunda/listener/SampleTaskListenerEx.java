package com.org.camunda.listener;

import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SampleTaskListenerEx implements TaskListener {
	Logger LOGGER = LoggerFactory.getLogger(SampleTaskListenerEx.class);
	
	@Override
	public void notify(DelegateTask delegateTask) {

		LOGGER.info("Welcome to taskListener!!"+delegateTask.getEventName());
	}

}
