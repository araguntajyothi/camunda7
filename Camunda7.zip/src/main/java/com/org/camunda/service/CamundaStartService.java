package com.org.camunda.service;
import com.org.camunda.pojo.Person;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CamundaStartService {

	@Autowired
	RuntimeService runtimeService;
	public void startProcessByMessage(Person person) {
		runtimeService.createMessageCorrelation("msg-s-1")
		.setVariable("msgname", person.getName())
		.setVariable("gender", person.getGender())
		.correlate();
		
	}

	public void startProcessByMessage2(String name) {
		
		runtimeService.createMessageCorrelation("msg-s-2")
		.setVariable("name", name)
		.correlate();
		
	}

}
