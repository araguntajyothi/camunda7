package com.org.camunda.pojo;

public class Summers {
	
	int num1;
	int num2;
	int num3;
	int num4;
	public int getNum1() {
		return num1;
	}
	public int getNum2() {
		return num2;
	}
	public int getNum3() {
		return num3;
	}
	public int getNum4() {
		return num4;
	}
	
	

}
