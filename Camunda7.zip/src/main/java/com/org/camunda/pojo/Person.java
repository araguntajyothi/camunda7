package com.org.camunda.pojo;

public class Person {

	String name;
	String gender;
	
	
	public Person(String name, String gender) {
		super();
		this.name = name;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public String getGender() {
		return gender;
	}
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
}
