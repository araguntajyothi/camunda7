package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceAgePrint implements JavaDelegate {

Logger LOGGER = LoggerFactory.getLogger(ServiceAgePrint.class);
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
//LOGGER.info("Result is: "+execution.getVariable("result"));

LOGGER.info("Result is: "+execution.getVariable("child-or-adult"));
	}

}
