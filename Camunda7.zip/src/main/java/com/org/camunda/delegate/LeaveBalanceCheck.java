package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LeaveBalanceCheck implements JavaDelegate {
   
	public static  int leave_balance;
	public static  int applied_leaves;
	
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {

		if(applied_leaves<=leave_balance) {
			logger.info("Your Leave Approved!!");
		} else {
			logger.info("Your Leave got rejected due to insufficeint leave balance");
		} 
	}

}
