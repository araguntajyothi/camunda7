package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MessageServiceDelegate implements JavaDelegate{

	Logger LOGGER = LoggerFactory.getLogger(MessageServiceDelegate.class);
	@Override
	public void execute(DelegateExecution execution) throws Exception {

		LOGGER.info("Exceute msgsample service1 ");
		execution.setVariable("servicevar","servicevalue");
	}

}
