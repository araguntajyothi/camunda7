package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SendTasks implements JavaDelegate {

	Logger LOGGER = LoggerFactory.getLogger(SendTasks.class);
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {

		LOGGER.info("Calling Another API!!");
		LOGGER.info("My Local gender variable: "+execution.getVariable("local-gender"));
	}

}
