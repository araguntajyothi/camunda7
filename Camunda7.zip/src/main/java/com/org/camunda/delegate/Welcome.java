package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.Expression;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.model.bpmn.instance.ServiceTask;
import org.camunda.bpm.model.bpmn.instance.camunda.CamundaProperties;
import org.camunda.bpm.model.bpmn.instance.camunda.CamundaProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Welcome implements JavaDelegate{
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private Expression qaUrl;
	@Override
	public void execute(DelegateExecution execution) throws Exception {

		logger.info("Welcome to the Camunda7 world");
		logger.info("My Field Injection value is: "+qaUrl.getValue(execution));
		
		ServiceTask serviceTask = (ServiceTask) execution.getBpmnModelElementInstance();
		
		CamundaProperties camundaProperties = serviceTask.getExtensionElements().getElementsQuery().filterByType(CamundaProperties.class).singleResult();
	
		for(CamundaProperty camundaProperty : camundaProperties.getCamundaProperties()){
			
			logger.info("name :"+camundaProperty.getCamundaName());
			logger.info("value : "+camundaProperty.getCamundaValue());
		}
	}

}
