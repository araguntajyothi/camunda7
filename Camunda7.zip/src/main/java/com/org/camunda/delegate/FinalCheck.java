package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FinalCheck implements JavaDelegate {

	Logger LOGGER = LoggerFactory.getLogger(FinalCheck.class);
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Iam in Final Check");
		LOGGER.info("My process global variable: "+execution.getVariable("global-gender"));
	}

}
