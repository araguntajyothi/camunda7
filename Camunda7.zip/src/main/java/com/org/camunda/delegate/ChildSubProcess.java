package com.org.camunda.delegate;

import java.util.Arrays;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChildSubProcess implements JavaDelegate {

	Logger logger = LoggerFactory.getLogger(ChildSubProcess.class);
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
//		logger.info("Inside Child Sub Process");
//		logger.info("UserName : "+execution.getVariable("username"));
		logger.info("Inside Test Class");
		List<String> list = Arrays.asList("akshaya", "jyothi","geetha");
		execution.setVariable("list", list);
		

	}

}
