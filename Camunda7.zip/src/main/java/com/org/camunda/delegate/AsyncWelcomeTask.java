package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AsyncWelcomeTask implements JavaDelegate {

	Logger logger = LoggerFactory.getLogger(AsyncWelcomeTask.class);
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		logger.info("Welcome to Camunda World!!");

	}

}
