package com.org.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AsyncPrintAgeTask implements JavaDelegate {
	Logger logger = LoggerFactory.getLogger(AsyncPrintAgeTask.class);
	@Override
	public void execute(DelegateExecution execution) throws Exception {

//		logger.info("Age is: "+execution.getVariable("age"));
		logger.info("Age is: "+execution.getVariable("age").toString());
		//logger.info("Age is: "+execution.getVariable("username").toString());
	}

}
