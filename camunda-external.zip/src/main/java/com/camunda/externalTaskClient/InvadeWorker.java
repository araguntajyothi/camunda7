package com.camunda.externalTaskClient;


import org.camunda.bpm.client.ExternalTaskClient;
import java.util.logging.Logger;


public class InvadeWorker {
	
	 private final static Logger LOGGER = Logger.getLogger(InvadeWorker.class.getName());

	  public static void main(String[] args) {
	    ExternalTaskClient client = ExternalTaskClient.create()
	        .baseUrl("http://localhost:8080/engine-rest")
	        .asyncResponseTimeout(10000) // long polling timeout
	        .build();

	    // subscribe to an external task topic as specified in the process
	    client.subscribe("InvadePersia")
	        .lockDuration(1000) // the default lock duration is 20 seconds, but you can override this
	        .handler((externalTask, externalTaskService) -> {

	          LOGGER.info("InvadepPersia!!!");

	          // Complete the task
	          externalTaskService.complete(externalTask);
	        })
	        .open();
	    
	    client.subscribe("InvadeGaul")
        .lockDuration(1000) // the default lock duration is 20 seconds, but you can override this
        .handler((externalTask, externalTaskService) -> {

          LOGGER.info("InvadeGaul!!!");

          // Complete the task
          externalTaskService.complete(externalTask);
        })
        .open();
	  }

}
